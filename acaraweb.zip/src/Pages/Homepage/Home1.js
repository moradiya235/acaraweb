import { Box, Container } from '@mui/material'
import React from 'react'

function Home1() {
  return (
    <Box sx={{}}>
       <Container>
        <Box>

        </Box>
       </Container> 
    </Box>
  )
}

export default Home1