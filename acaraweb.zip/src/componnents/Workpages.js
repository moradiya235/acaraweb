import React from 'react';
import Work1 from '../Pages/work pages/Work1';
import Work2 from '../Pages/work pages/Work2';
import Work3 from '../Pages/work pages/Work3';

function Workpages() {
  return (
    <div>
         <Work1/>
         <Work2/> 
         <Work3/>
    </div>
  );
}

export default Workpages;
