import React from 'react';
import Services1 from '../Pages/Services/Services1';
import Services2 from '../Pages/Services/Services2';

function Services() {
  return (
    <div>
          <Services1/>
          <Services2/>
    </div>
  );
}

export default Services;
