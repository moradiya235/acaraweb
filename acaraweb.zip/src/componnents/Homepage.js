import React from 'react'
import Home1 from '../Pages/Homepage/Home1'

function Homepage() {
  return (
    <div>
        <Home1/>
    </div>
  )
}

export default Homepage