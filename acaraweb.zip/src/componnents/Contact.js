import React from 'react';
import Contact1 from '../Pages/contact/Contact1';

function Contact() {
  return (
    <>
     <Contact1/>
    </>
  );
}

export default Contact;
